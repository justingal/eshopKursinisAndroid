﻿using UnityEngine;

public class InvaderData : MonoBehaviour
{
    public int scoreValue; // Taškų vertė už sunaikintą priešą

}
